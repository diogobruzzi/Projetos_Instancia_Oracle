# VS Code Server + OAuth2-Proxy (Google 2FA) - Setup Guide

## Visão Geral

Stack completo para rodar VS Code Server (code-server) com autenticação Google OAuth + 2FA via **oauth2-proxy**, atrás de **Caddy** com HTTPS automático (Let's Encrypt).

```
┌─────────────────────────────────────────────────────────────────┐
│                        INTERNET (HTTPS)                         │
└─────────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                        CADDY (ports 80/443)                     │
│  - Terminação TLS (Let's Encrypt)                               │
│  - Forward auth → oauth2-proxy                                  │
│  - Security headers                                             │
└─────────────────────────────────────────────────────────────────┘
                                  │
              ┌───────────────────┼───────────────────┐
              ▼                   ▼                   ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│   oauth2-proxy   │  │   oauth2-proxy   │  │   oauth2-proxy   │
│   (port 4180)    │  │   (port 4180)    │  │   (port 4180)    │
│                  │  │                  │  │                  │
│ - Google OAuth   │  │ - Google OAuth   │  │ - Google OAuth   │
│ - /oauth2/*      │  │ - /oauth2/*      │  │ - /oauth2/*      │
│ - Valida sessão  │  │ - Valida sessão  │  │ - Valida sessão  │
└────────┬─────────┘  └────────┬─────────┘  └────────┬─────────┘
         │                     │                     │
         └─────────────────────┼─────────────────────┘
                               ▼
         ┌─────────────────────────────────────┐
         │        CODE-SERVER (port 8080)      │
         │  - auth: none (oauth2-proxy protege)│
         │  - Workspace: /home/coder/project   │
         └─────────────────────────────────────┘
```

---

## Componentes

| Serviço | Imagem | Porta | Função |
|---------|--------|-------|--------|
| Caddy | `caddy:2-alpine` | 80, 443 | Reverse proxy, TLS, forward_auth |
| oauth2-proxy | `quay.io/oauth2-proxy/oauth2-proxy:v7.8.0` | 4180 | Google OAuth + 2FA, sessões |
| code-server | `codercom/code-server:4.145.2` | 8080 | VS Code no browser |

---

## Pré-requisitos

1. **Domínio** apontando para o servidor (ex: `iadcmb.duckdns.org`, `vscode.iadcmb.duckdns.org`)
2. **Google Cloud Console** project com OAuth 2.0 Client ID
3. **Docker** + **Docker Compose** instalados
4. Portas 80 e 443 abertas no firewall/cloud

---

## 1. Google OAuth Setup

### Criar credenciais

1. Acesse: https://console.cloud.google.com/apis/credentials
2. **Create Credentials** → **OAuth client ID**
3. Application type: **Web application**
4. Name: `code-server-oauth`
5. **Authorized redirect URIs**:
   ```
   https://vscode.iadcmb.duckdns.org/oauth2/callback
   https://iadcmb.duckdns.org/oauth2/callback
   ```
6. Copie **Client ID** e **Client Secret**

### Configurar tela de consentimento (opcional)

- OAuth consent screen → External → Add scopes: `email`, `profile`, `openid`
- Test users: adicione seu email Google

---

## 2. Configuração do Servidor

### Estrutura de diretórios

```
/opt/codeserver/
├── .env                          # Segredos (não commitar!)
├── docker-compose.yml            # Orquestração
├── caddy_config/
│   └── Caddyfile                 # Config Caddy
├── oauth2_proxy_config/
│   └── oauth2-proxy.cfg          # Config oauth2-proxy
├── codeserver_config/
│   └── config.yaml               # Config code-server
└── workspace/                    # Montado em /home/coder/project
```

### .env (preencha com seus valores)

```bash
DOMAIN=iadcmb.duckdns.org
SUBDOMAIN=vscode
FQDN=vscode.iadcmb.duckdns.org
EMAIL=seu@email.com

# code-server (não usado com oauth2-proxy, mas mantido p/ referência)
CODESERVER_PASSWORD=LKzISPb8

# oauth2-proxy — OBRIGATÓRIO PREENCHER
OAUTH2_PROXY_CLIENT_ID=seu-google-client-id.apps.googleusercontent.com
OAUTH2_PROXY_CLIENT_SECRET=GOCSPX-seu-client-secret
OAUTH2_PROXY_COOKIE_SECRET=ZitYAt93RYszfeRHslU4tuO9adhDKq0a  # gerado com openssl

DATA_DIR=/opt/codeserver
```

**Gerar cookie secret:**
```bash
openssl rand -base64 32 | tr -d '/+=' | head -c 32
```

---

## 3. Deploy

```bash
cd /opt/codeserver

# Subir stack
docker compose up -d

# Ver logs
docker compose logs -f caddy
docker compose logs -f oauth2-proxy
docker compose logs -f codeserver

# Verificar status
docker compose ps
```

### Verificar saúde

```bash
# Caddy - certificados
curl -k https://iadcmb.duckdns.org/healthz
curl -k https://vscode.iadcmb.duckdns.org/healthz

# oauth2-proxy
curl -k https://iadcmb.duckdns.org/oauth2/ping
# Resposta: "pong"

# code-server (via proxy)
curl -k -H "Cookie: _oauth2_proxy=..." https://iadcmb.duckdns.org/
```

---

## 4. Primeiro Acesso

1. Acesse: **https://iadcmb.duckdns.org/** ou **https://vscode.iadcmb.duckdns.org/**
2. Redireciona para **Google OAuth**
3. Login com sua conta Google
4. Se tiver **2FA no Google**, será solicitado
5. Após autorização, redireciona para code-server logado

**Cabeçalhos passados ao code-server:**
- `X-Forwarded-User` - email Google
- `X-Forwarded-Email` - email Google
- `X-Forwarded-Groups` - grupos (se configurado)
- `X-Forwarded-Preferred-Username` - nome de usuário

---

## 5. Configurações Avançadas

### Restringir acesso a emails específicos

No `oauth2-proxy.cfg` ou via env:

```bash
# .env
OAUTH2_PROXY_EMAIL_DOMAINS=seudominio.com,outrodominio.com
# ou emails específicos
OAUTH2_PROXY_ALLOWED_EMAILS=user1@gmail.com,user2@empresa.com
```

### Apenas usuários de grupo Google Workspace

```bash
OAUTH2_PROXY_GOOGLE_GROUP=grupo@seudominio.com
OAUTH2_PROXY_GOOGLE_ADMIN_EMAIL=admin@seudominio.com
# Requer Service Account com delegação domain-wide
```

### Customizar tempo de sessão

```ini
# oauth2-proxy.cfg
cookie_expire = "168h"    # 7 dias
cookie_refresh = "1h"     # renova a cada 1h
```

### Habilitar HTTPS no code-server (opcional)

Se quiser TLS end-to-end (Caddy → code-server):

1. Gere certs auto-assinados para `codeserver` (mkcert ou similar)
2. No `config.yaml`:
   ```yaml
   cert: true
   cert-file: /home/coder/.config/code-server/cert.pem
   cert-key: /home/coder/.config/code-server/key.pem
   ```
3. No Caddyfile: `reverse_proxy codeserver:8080 { transport http { tls_insecure_skip_verify } }`

---

## 6. Troubleshooting

### Caddy não emite certificado

```bash
# Ver logs
docker compose logs caddy | grep -i acme

# Verificar DNS
dig +short iadcmb.duckdns.org
dig +short vscode.iadcmb.duckdns.org

# Portas 80/443 acessíveis?
curl -I http://iadcmb.duckdns.org
```

### oauth2-proxy erro "invalid redirect_uri"

- Verifique se **Authorized redirect URIs** no Google Console batem exatamente:
  - `https://vscode.iadcmb.duckdns.org/oauth2/callback`
  - `https://iadcmb.duckdns.org/oauth2/callback`
- Sem trailing slash, HTTPS, domínio exato

### Loop de redirecionamento infinito

- `cookie_secure = true` requer HTTPS
- `cookie_samesite = "lax"` funciona cross-site
- Verifique se `redirect_url` no config bate com o domínio real

### code-server não carrega / WebSocket falha

- Caddy suporta WebSocket nativamente
- Verifique `PROXY_DOMAIN` no code-server = domínio real
- Headers `Upgrade` e `Connection` passam automático

### Permissão negada em volumes

```bash
# Corrigir ownership (code-server roda como uid 1000)
sudo chown -R 1000:1000 /opt/codeserver/codeserver_config
sudo chown -R 1000:1000 /opt/codeserver/oauth2_proxy_config
sudo chown -R 1000:1000 /opt/codeserver/workspace
```

---

## 7. Backup & Restore

### Backup

```bash
#!/bin/bash
BACKUP_DIR="/backup/codeserver-$(date +%F)"
mkdir -p "$BACKUP_DIR"
cp -r /opt/codeserver/caddy_data "$BACKUP_DIR/"
cp -r /opt/codeserver/caddy_config "$BACKUP_DIR/"
cp -r /opt/codeserver/codeserver_config "$BACKUP_DIR/"
cp -r /opt/codeserver/workspace "$BACKUP_DIR/"
cp /opt/codeserver/.env "$BACKUP_DIR/"
tar -czf "$BACKUP_DIR.tar.gz" -C "$BACKUP_DIR" .
echo "Backup salvo em $BACKUP_DIR.tar.gz"
```

### Restore

```bash
# Parar stack
docker compose down

# Restaurar
tar -xzf /backup/codeserver-2026-01-15.tar.gz -C /opt/codeserver/

# Ajustar permissões
sudo chown -R 1000:1000 /opt/codeserver/codeserver_config
sudo chown -R 1000:1000 /opt/codeserver/oauth2_proxy_config
sudo chown -R 1000:1000 /opt/codeserver/workspace

# Subir
docker compose up -d
```

---

## 8. Atualizações

```bash
# Pull imagens novas
docker compose pull

# Recriar containers
docker compose up -d --force-recreate

# Limpar imagens antigas
docker image prune -f
```

---

## 9. Segurança

### ✅ Já implementado

- TLS 1.3 automático (Let's Encrypt)
- Security headers (HSTS, CSP-ready, X-Frame-Options, etc.)
- Forward auth (oauth2-proxy valida cada request)
- Cookies HttpOnly + Secure + SameSite=Lax
- code-server sem auth exposta (protegido por oauth2-proxy)
- Senhas/segredos só em `.env` (não no código)

### 🔧 Recomendações extras

- **Fail2ban** no host para portas 80/443
- **Rate limiting** no Caddy (requer module `caddy-ratelimit`)
- **WAF** (CrowdSec, ModSecurity) se exposto público
- **Auditoria** logs de acesso Caddy + oauth2-proxy
- **Rotação** de `OAUTH2_PROXY_COOKIE_SECRET` a cada 90 dias
- **Monitoramento** health checks + alertas (Uptime Kuma, Prometheus)

---

## 10. Comandos Úteis

```bash
# Status
docker compose ps
docker compose logs -f --tail=100

# Reiniciar serviço específico
docker compose restart caddy
docker compose restart oauth2-proxy
docker compose restart codeserver

# Shell no container
docker compose exec codeserver bash
docker compose exec oauth2-proxy sh

# Ver config efetiva
docker compose config

# Parar tudo
docker compose down

# Parar + remover volumes (CUIDADO: apaga certs TLS!)
docker compose down -v

# Ver uso de recursos
docker stats --no-stream
```

---

## 11. Referências

- [oauth2-proxy docs](https://oauth2-proxy.github.io/oauth2-proxy/)
- [Caddy docs](https://caddyserver.com/docs/)
- [code-server docs](https://github.com/coder/code-server)
- [Google OAuth 2.0](https://developers.google.com/identity/protocols/oauth2)
- [Let's Encrypt rate limits](https://letsencrypt.org/docs/rate-limits/)

---

## Changelog

| Data | Versão | Mudanças |
|------|--------|----------|
| 2026-11-08 | 1.0 | Setup inicial: Caddy + oauth2-proxy (Google) + code-server |

---

**⚠️ IMPORTANTE:** Nunca commite o arquivo `.env` no git. Adicione ao `.gitignore`:

```gitignore
/opt/codeserver/.env
/opt/codeserver/caddy_data/
/opt/codeserver/caddy_config/autosave.json
```