#!/usr/bin/env bash
# Auto-enable caveman mode on session start
# This runs via SessionStart hook in settings.json

# Ativa caveman mode
echo "/caveman" | /home/coder/.local/bin/claude --print 2>/dev/null || true

# Se quiser ultracave (mais extremo), descomente:
# echo "/caveman ultra" | /home/coder/.local/bin/claude --print 2>/dev/null || true