#!/usr/bin/env python3
"""
Caveman Compress CLI

Usage:
    caveman <filepath>
"""

import argparse
import sys

# Force UTF-8 on stdout/stderr before any code can print. Windows consoles
# default to cp1252 and crash on the ❌ glyphs in error/validation branches,
# masking the real error and leaving the user with a half-compressed file.
for _stream in (sys.stdout, sys.stderr):
    reconfigure = getattr(_stream, "reconfigure", None)
    if callable(reconfigure):
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

from pathlib import Path

# Direct script execution has no package context. Resolve imports relative to
# this installed skill, independent of the caller's working directory.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    __package__ = "scripts"

from .compress import backup_dir_for, compress_file, is_sensitive_path
from .detect import detect_file_type, should_compress


def main():
    parser = argparse.ArgumentParser(description="Compress a natural-language file with validation and an original backup.")
    parser.add_argument("filepath", type=Path, help="path to the file to compress")
    filepath = parser.parse_args().filepath

    # Check file exists
    if not filepath.exists():
        print(f"❌ File not found: {filepath}")
        sys.exit(1)

    if not filepath.is_file():
        print(f"❌ Not a file: {filepath}")
        sys.exit(1)

    filepath = filepath.resolve()

    # Refuse before detect_file_type(), which reads extensionless files to sniff them.
    if is_sensitive_path(filepath):
        print(f"❌ Refusing to compress {filepath}: filename looks sensitive "
              "(credentials, keys, secrets, or known private paths). "
              "Rename the file if this is a false positive.")
        sys.exit(1)

    # Detect file type
    file_type = detect_file_type(filepath)

    print(f"Detected: {file_type}")

    # Check if compressible
    if not should_compress(filepath):
        print("Skipping: file is not natural language (code/config)")
        sys.exit(0)

    print("Starting caveman compression...\n")

    try:
        success = compress_file(filepath)

        if success:
            print("\nCompression completed successfully")
            backup_path = backup_dir_for(filepath) / (filepath.stem + ".original.md")
            print(f"Compressed: {filepath}")
            print(f"Original:   {backup_path}")
            sys.exit(0)
        else:
            # Also reached when no attempt ran (backup exists, empty file, ...).
            print("\n❌ Compression did not complete (see above). Original file is untouched.")
            sys.exit(2)

    except KeyboardInterrupt:
        print("\nInterrupted by user")
        sys.exit(130)

    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
