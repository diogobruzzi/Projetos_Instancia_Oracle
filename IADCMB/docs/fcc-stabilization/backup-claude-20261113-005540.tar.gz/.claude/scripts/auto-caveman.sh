#!/usr/bin/env bash
# Auto-enable caveman mode on session start
# This runs via SessionStart hook in settings.json

# Ativa caveman mode
echo "/caveman" | /home/ubuntu/.local/bin/claude --print 2>/dev/null || true

# Se quiser ultracave (mais extremo), descomente:
# echo "/caveman ultra" | /home/ubuntu/.local/bin/claude --print 2>/dev/null || true